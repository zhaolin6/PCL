from __future__ import print_function
from __future__ import division
import torch
import torch.nn.functional as F
from resnet import get_model
import numpy as np
import random
import torch.nn as nn
from tqdm import tqdm
import torch.optim as optim
import os
from utils import grouper, sliding_window, count_sliding_window,\
                  camel_to_snake,metrics
from sklearn.externals import joblib



def test2(net, img, test_gt, hyperparams):
    """
    Test a model on a specific image
    """
    net.eval()
    patch_size = hyperparams['patch_size']
    center_pixel = hyperparams['center_pixel']
    batch_size, device = hyperparams['batch_size'], hyperparams['device']
    n_classes = hyperparams['n_classes']

    kwargs = {'step': hyperparams['test_stride'], 'window_size': (patch_size, patch_size)}
    probs = np.zeros(img.shape[:2] + (n_classes,))

    iterations = count_sliding_window(img, **kwargs) // batch_size
    for batch in tqdm(grouper(batch_size, sliding_window(img, **kwargs)),
                      total=(iterations),
                      desc="Inference on the image"
                      ):
        with torch.no_grad():
            if patch_size == 1:
                data = [b[0][0, 0] for b in batch]
                data = np.copy(data)
                data = torch.from_numpy(data)
            else:
                data = [b[0] for b in batch]
                data = np.copy(data)
                data = data.transpose(0, 3, 1, 2)
                data = torch.from_numpy(data)
                # data = data.unsqueeze(1)

            indices = [b[1:] for b in batch]
            data = data.to(device)
            output = net(data)
            if isinstance(output, tuple):
                output = output[0]
            output = output.to('cpu')  # 将cpu 改为 cuda

            if patch_size == 1 or center_pixel:
                output = output.numpy()
            else:
                output = np.transpose(output.numpy(), (0, 2, 3, 1))
            for (x, y, w, h), out in zip(indices, output):
                if center_pixel:
                    # probs[x, y] += out
                    probs[x + w // 2, y + h // 2] += out
                    # probs[x:x + w, y:y + h] += out
                else:
                    probs[x:x + w, y:y + h] += out
    prediction = np.argmax(probs, axis=-1)
    prediction = prediction[(patch_size // 2):-(patch_size // 2),
                 (patch_size // 2):-(patch_size // 2)]
    test_gt = test_gt[(patch_size // 2):-(patch_size // 2),
                 (patch_size // 2):-(patch_size // 2)]
    run_results = metrics(prediction, test_gt, ignored_labels=hyperparams['ignored_labels'], n_classes=n_classes)
    return run_results, prediction


def get_train(gt, num, N_CLASSES):
    mask = np.zeros_like(gt)
    x_pos, y_pos = np.nonzero(gt)  # 返回mask中非零值得索引值 即pix在图中的坐标
    indice = list(zip(x_pos, y_pos))
    index = [[],[],[],[],[],[],[],[],[],[]]
    for x, y in indice:
        for i in range(1, N_CLASSES):
            if gt[x][y] == i:
                pos = (x,y)
                index[i].append(pos)

    for i in range(1,N_CLASSES):
        index[i] = random.choices(index[i], k=num)

    for i in range(1, N_CLASSES):
        for x, y in index[i]:
                mask[x, y] = gt[x, y]
    return mask, index

def build_model(name ,**kwargs ):
    model = get_model(name, **kwargs)

    if torch.cuda.is_available():
        model.cuda()
        torch.backends.cudnn.benchmark = True

    return model


def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res


def text_save(filename, data):#filename为写入CSV文件的路径，data为要写入数据列表.
    file = open(filename,"r+")
    for i in range(len(data)):
        s = str(data[i]).replace('[','').replace(']','')#去除[],这两行按数据不同，可以选择
        s = s.replace("'",'') +'\n'   #去除单引号，逗号，每行末尾追加换行符
        file.write(s)
    file.close()


def label_noise(img, gt, noise_num, index, N_CLASSES):
    # 加噪
    indice = []
    for i in range(1,N_CLASSES):
        noise_indice = random.choices(index[i], k=noise_num)
        indice.append(noise_indice)
    #修改gt
        noise_value = []
        for x, y in noise_indice:
            noise_label = gt[x, y]
            while (noise_label == gt[x, y]):
                noise_label = random.randint(1, N_CLASSES - 1)
                if noise_label != gt[x, y]:
                    noise_value.append(noise_label)

            gt[x, y] = noise_label
        # text_save('record/noise_indices.txt', noise_indice)
        # text_save('record/noise_value.txt', noise_value)
    return gt, indice


def get_label_noise(gt,noise_indices_path, noise_value_path ):
    noise_indices = open(noise_indices_path,"r+")
    noise_value = open(noise_value_path,"r+")
    for x, i in zip(noise_indices, noise_value):
        indice = eval(x)
        gt[indice[0], indice[1]] = i
    return gt


def get_window(img,gt,patch_size=21):
    y = 0
    indice_x = []
    indice_y = []
    indice = []
    data = []
    label = []
    for x in range(0, len(gt) - 1):
        for l in gt[x]:
            if l != 0:
                indice_x.append(x)
                indice_y.append(y)
                indice = list(zip(indice_x, indice_y))
                x1, y1 = x - patch_size // 2, y - patch_size // 2  # 计算出目标window
                x2, y2 = x1 + patch_size, y1 +patch_size
                data.append(img[x1:x2, y1:y2, :])
                label.append(l)
            y += 1
        y = 0
    return data, indice, label


# def noise_W(index,noise_indice):






